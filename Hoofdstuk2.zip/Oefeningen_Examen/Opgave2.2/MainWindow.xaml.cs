﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Opgave2._2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void visibleButton_Click(object sender, RoutedEventArgs e)
        {
            colouredLabel.Visibility = Visibility.Visible;
        }

        private void invisibleButton_Click(object sender, RoutedEventArgs e)
        {
            colouredLabel.Visibility = Visibility.Hidden;
        }
    }
}