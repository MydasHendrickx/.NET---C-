﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Opgave2._5
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
